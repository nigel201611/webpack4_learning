describe('单元检测',function(){
	it('大拇指点赞',function(){
		expect(window.add(1)).toBe(2)
	})
})