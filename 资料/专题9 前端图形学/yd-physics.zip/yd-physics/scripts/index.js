class SimpleGame {
    constructor() {
        this.game = new Phaser.Game(800, 600, Phaser.CANVAS, "test", {
            preload: this.preload,
            create: this.create,
            update: this.update
        })
    }
    preload() {
        this.load.image("sky", "images/sky.png");
        this.load.spritesheet("dude", "images/dude.png", 32, 48);
        this.load.image("ground", "images/platform.png");
        this.load.image("star", "images/star.png");
    }
    create() {
        this.physics.startSystem(Phaser.Physics.ARCADE);
        this.add.sprite(0, 0, "sky");
        //开启物理引擎
        this.platforms = this.add.group();
        const _platforms = this.platforms;
        _platforms.enableBody = true;
        //地面
        const ground = _platforms.create(0, this.world.height - 32, "ground");
        ground.scale.setTo(2,1);
        ground.body.immovable = true;
        const ledge = _platforms.create(400, 400, "ground");
        ledge.body.immovable = true;
        const ledge2 = _platforms.create(-150, 250, "ground");
        ledge2.body.immovable = true;
        this.player = this.add.sprite(32, this.world.height - 150, "dude");
        this.star = this.add.sprite(200, this.world.height - 80, "star");
        //主人公
        const _player = this.player;
        // this.stars = this.add.group();
        // let _stars = this.stars;
        // _stars.enableBody = true;
        // let star = _stars.create(200,this.world.height -80,"star");
        //this.star.body.bounce.y = 0.1;
        this.physics.arcade.enable(_player);
        this.physics.arcade.enable(this.star);
        _player.body.bounce.y = 0.3;
        _player.body.gravity.y = 300;
        //开启边缘检测
        _player.body.collideWorldBounds = true;
        _player.animations.add("left", [0, 1, 2, 3], 10, true);
        _player.animations.add("right", [ 5, 6, 7, 8], 10, true);
        // _player.animations.play("left");
        this.cursors = this.input.keyboard.createCursorKeys(); 
    }
    update() {
        const _physics = this.physics;
        const _player = this.player;
        const _platforms = this.platforms;
        const _cursors = this.cursors;
        const _star = this.star;
        _physics.arcade.collide(_player,_platforms);
        //_physics.arcade.collide(_player,this.star);
        _physics.arcade.overlap(_player,_star,(player,star)=>{
            console.log("生效了")
            star.kill();
        },null,this);
        if(_cursors.left.isDown){
            _player.animations.play("left");
            _player.body.velocity.x = -150;
        }else if(_cursors.right.isDown){
            _player.animations.play("right");
            _player.body.velocity.x = 150;
        }else{
            _player.animations.stop();
            _player.body.velocity.x = 0;
            _player.frame = 4;
        }
        if(this.cursors.up.isDown){
            _player.body.velocity.y = -350;
        }
    }
}
const gameIns = new SimpleGame();