/**
 * @description 物理引擎的说明
 * 空间的概念 Space 物理空间
 * 物体 body 空间里要存放物体
 * 形状 shape 包裹物体
 * 精灵 sprite 游戏中的主人翁
 * 空间->物体->形状-> 链接到一个精灵
 * 关节 joint 用来约束物体的链接的情况
 */
var SPRITE_HEIGHT = 72;
var SPRITE_WIDTH = 72;
var COLLISION_TYPE = 1;
var HelloWorldLayer = cc.Layer.extend({
    sprite: null,
    ctor: function () {
        this._super();
        var sprite = new cc.Sprite(res.bj_jpg);
        var size = cc.winSize;
        sprite.setPosition(size.width / 2, size.height / 2);
        this.addChild(sprite);
        //初始化物理引擎
        this.initPhysics();
        //开启游戏的循环
        this.scheduleUpdate();
        return true;
    },
    initPhysics: function () {
        //创建物理空间
        this.space = new cp.Space();
        //打开调试工具
        //this.setupDebugNode();
        this.space.gravity = cp.v(0, -100);
        var staticBody = this.space.staticBody;
        var walls = [
            new cp.SegmentShape(staticBody, cp.v(0, 0), cp.v(cc.winSize.width, 0), 10),
            new cp.SegmentShape(staticBody, cp.v(0, cc.winSize.height), cp.v(cc.winSize.width - 800, cc.winSize.height / 2 + 260), 20),
            new cp.SegmentShape(staticBody, cp.v(cc.winSize.width - 800, cc.winSize.height / 2 + 260), cp.v(cc.winSize.width - 500, cc.winSize.height / 2 + 110), 20),
            new cp.SegmentShape(staticBody, cp.v(cc.winSize.width - 500, cc.winSize.height / 2 + 110), cp.v(cc.winSize.width - 200, cc.winSize.height / 2 - 120), 20)
        ]
        for (var i = 0; i < walls.length; i++) {
            var shape = walls[i];
            //设置每一条先的弹性系数
            shape.setElasticity(1);
            //设置摩擦系数
            shape.setFriction(1);
            //这条线加入到当前的空间
            this.space.addStaticShape(shape);
        }
        //设置碰撞检测
        this.space.addCollisionHandler(
            COLLISION_TYPE,
            COLLISION_TYPE,
            this.collisionBeigin.bind(this),
            this.collisionPre.bind(this),
            this.collisionPost.bind(this),
            this.collisionSeparate.bind(this),
        )
    },
    collisionBeigin: function (arbiter,space) {
    },
    collisionPre: function () {},
    collisionPost: function () {},
    collisionSeparate: function (arbiter,space) {
        var shapes = arbiter.getShapes();
        var bodyA = shapes[0].body;
        var spriteA = bodyA.data;
        this.showEffect(spriteA)
    },
    showEffect: function (spriteA) {
        //粒子效果
        this._particleSystem = new cc.ParticleSystem(res.First_plist);
        this._particleSystem.setAutoRemoveOnFinish(true);
        var size = spriteA.getPosition();
        this._particleSystem.setPositionX(size.x - 10);
        this._particleSystem.setPositionY(size.y);
        this.addChild(this._particleSystem);
    },
    add() {
        //创建物体
        var body = cp.Body(1, cp.momentForBox())

        var shape = new cp.BoxShape(body);
        shape.setElasticity()
        shape.setFriction();

        var sprite = new cc.PhysicsSprite()
        sprite.setBody(body);
    },
    onEnter: function () {
        this._super();
        cc.log("Enter");
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: this.onTouchBegan
        }, this);
    },
    createBody: function (filename, p) {
        //物体->形状-> 链接到一个精灵
        //1.创建一个质量m=1的物体 受到阻力 惯性力矩 宽度 高度
        var body = new cp.Body(1, cp.momentForBox(1, SPRITE_WIDTH, SPRITE_HEIGHT));
        body.p = p;
        this.space.addBody(body);
        //2.创建一个形状
        var shape = new cp.BoxShape(body, SPRITE_WIDTH, SPRITE_HEIGHT);
        //设置性状的弹性系数
        shape.setElasticity(0.5);
        //设置摩擦系数
        shape.setFriction(0.5);
        shape.setCollisionType(COLLISION_TYPE);
        this.space.addShape(shape);
        //3.创建一个雪碧图
        var sprite = new cc.PhysicsSprite(filename);
        sprite.setBody(body);
        sprite.setPosition(cc.p(p.x, p.y));
        this.addChild(sprite);
        //元数据 
        body.data = sprite;
        return body;
    },
    addNewSpriteAtPosition: function (p) {
        cc.log("addNewSpriteAtPosition", p)
        var body1 = this.createBody(res.Stone_png, p);
        var body2 = this.createBody(res.Snowman_png, cc.pAdd(p, cc.p(80, -80)));
        //用关节关联起来
        this.space.addConstraint(new cp.PinJoint(body1, body2, cp.v(0, 0), cp.v(0, SPRITE_HEIGHT / 2)))
    },
    onTouchBegan: function (touch, event) {
        cc.log("onTouchBegan");
        var target = event.getCurrentTarget();
        var location = touch.getLocation();
        target.addNewSpriteAtPosition(location);
        return false;
    },
    setupDebugNode: function () {
        this._debugNode = new cc.PhysicsDebugNode(this.space);
        this._debugNode.visible = true;
        this.addChild(this._debugNode);
    },
    update: function (dt) {
        var timeStep = 0.04;
        this.space.step(timeStep);
    }
});

var HelloWorldScene = cc.Scene.extend({
    onEnter: function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});