echo "🍌"
yarn install
pm2 restart app
