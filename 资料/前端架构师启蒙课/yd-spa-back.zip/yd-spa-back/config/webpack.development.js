module.exports = {
    output:{
        filename:"scripts/[name].bundles.js"
    }
};