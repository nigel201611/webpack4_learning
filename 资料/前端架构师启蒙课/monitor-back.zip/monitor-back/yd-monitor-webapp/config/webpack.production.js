// const WebpackParallelUglifyPlugin = require('webpack-parallel-uglify-plugin');
//webpack 官网推荐
//const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const glob = require('glob');
const {
    join
} = require("path");
const os = require('os');
const webpack = require("webpack");
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const ManifestPlugin = require('webpack-manifest-plugin');
module.exports = {
    output: {
        path: join(__dirname + "../../../" + "yd-monitor/assets/"),
        filename: "scripts/[name].[contenthash:5].bundle.js",
        publicPath: '/' 
    },
    // optimization: {
    //     minimizer: [
    //         new UglifyJsPlugin({
    //             exclude: /\.min\.js$/, // 过滤掉以".min.js"结尾的文件，我们认为这个后缀本身就是已经压缩好的代码，没必要进行二次压缩
    //             cache: true,
    //             parallel: os.cpus().length, //true
    //             sourceMap: false,
    //             extractComments: false, // 移除注释
    //             uglifyOptions: {
    //                 compress: {
    //                     warnings: false,
    //                     drop_console: true,
    //                     collapse_vars: true,
    //                     reduce_vars: true
    //                 }
    //             }
    //         })
    //     ]
    // },
    plugins: [
        //new ManifestPlugin(),
        // new OptimizeCssAssetsPlugin({
        //     // assetNameRegExp: /\.optimize\.css$/g,
        //     assetNameRegExp: /\.css$/g,
        //     //摈弃重复的样式定义、砍掉样式规则中多余的参数、移除不需要的浏览器前缀等
        //     cssProcessor: require('cssnano'),
        //     //autoprefixer: { disable: true }, 
        //     cssProcessorPluginOptions: {
        //         preset: ['default', {
        //             discardComments: {
        //                 removeAll: true
        //             }
        //         }],
        //     },
        //     canPrint: true
        // }),
        //uglifyJS
        // new WebpackParallelUglifyPlugin({
        //     exclude: /\.min\.js$/, // 过滤掉以".min.js"结尾的文件，我们认为这个后缀本身就是已经压缩好的代码，没必要进行二次压缩
        //     workerCount: os.cpus().length, //开启几个子进程去并发的执行压缩。默认是当前运行电脑的 CPU 核数减去1
        //     parallel: true, // 开启并行压缩，充分利用cpu
        //     uglifyES: {
        //         output: {
        //             beautify: false, //不需要格式化
        //             comments: false //不保留注释
        //         },
        //         compress: {
        //             warnings: false, // 在UglifyJs删除没有用到的代码时不输出警告
        //             drop_console: true, // 删除所有的 `console` 语句，可以兼容ie浏览器
        //             collapse_vars: true, // 内嵌定义了但是只用到一次的变量
        //             reduce_vars: true // 提取出出现多次但是没有定义成变量去引用的静态值
        //         }
        //     }
        // }),
    ]
};