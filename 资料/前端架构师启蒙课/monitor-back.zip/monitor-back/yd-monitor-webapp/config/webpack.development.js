const webpack = require("webpack");
const {
    join
} = require("path");
module.exports = {
    output: {
        path: join(__dirname + "../../../" + "yd-monitor/assets/"),
        filename: "scripts/[name].bundle.js",
        publicPath: '/' 
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
    ]
};