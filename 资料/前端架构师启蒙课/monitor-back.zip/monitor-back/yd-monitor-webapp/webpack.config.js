const HtmlWebpackPlugin = require('html-webpack-plugin');
const argv = require('yargs-parser')(process.argv.slice(2));
const _mode = argv.mode || "development";
const _modeflag = (_mode == "production" ? true : false);
// const CleanWebpackPlugin = require('clean-webpack-plugin');
const merge = require('webpack-merge');
const webpack = require("webpack");
const {
    resolve,
    join
} = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const _mergeConfig = require(`./config/webpack.${_mode}.js`);
const SpeedMeasurePlugin = require("speed-measure-webpack-plugin");
const smp = new SpeedMeasurePlugin();
const ProgressBarPlugin = require('progress-bar-webpack-plugin');
// const InlineManifestWebpackPlugin = require("inline-manifest-webpack-plugin");
const loading = {
    html: "加载中..."
};
const WebpackBuildNotifierPlugin = require('webpack-build-notifier');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const FilterWarningsPlugin = require('webpack-filter-warnings-plugin');
let cssLoaders = [
    MiniCssExtractPlugin.loader,
    //'style-loader',
    {
        loader: "css-loader?modules&localIdentName=[name]__[local]-[hash:base64:5]",
        options: {
            //importLoaders: 1,
            minimize: _modeflag
        }
    },
    {
        loader: 'postcss-loader'
    }
];
//如果是开发环境 把热更新的loader放进来
!_modeflag && cssLoaders.unshift('css-hot-loader');
const webpackConfig = {
    entry: {
        polyfills: join(__dirname, './polyfills.ts'),
        main: join(__dirname, './main.ts')
    },
    // mode:_mode,
    module: {
        rules: [{
            test: /\.ts$/,
            loaders: [{
                    loader: 'awesome-typescript-loader',
                    options: {
                        transpileOnly: process.env.NODE_ENV !== 'production'
                    }
                },
                'angular2-template-loader',
                'angular2-router-loader'
            ]
        }, {
            test: /\.html$/,
            use: [{
                loader: 'html-loader',
            }],
        }, {
            test: /\.css$/,
            //include: [resolve('src')], //限制范围，提高打包速度
            enforce: 'pre',
            exclude: /node_modules/,
            use: cssLoaders
        }, {
            test: /\.css$/,
            use: [{
                loader: "raw-loader" // creates style nodes from JS strings
            }],
        }, {
            test: /\.(jpe?g|png|gif|svg)$/,
            loader: 'image-webpack-loader',
            enforce: 'pre',
            options: {
                pngquant: {
                    quality: '65-90', //最小值和最大值0-100 所需的最少量的颜色
                    speed: 4 //1-10 代表速度
                }
            }
        }, {
            test: /\.(png|jpg|gif|eot|woff|woff2|ttf|svg|otf)$/,
            use: [{
                // loader: 'file-loader',
                loader: "url-loader",
                options: {
                    // 小于 10kB(10240字节）的内联文件
                    limit: 10 * 1024,
                    name: _modeflag ?
                        "images/[name].[hash:5].[ext]" : "images/[name].[ext]"
                }
            }]
        }]
    },
    // watch: !_modeflag,
    devtool: _modeflag ? '' : 'cheap-module-eval-source-map', //source-map
    watchOptions: {
        ignored: /node_modules/, //忽略不用监听变更的目录
        aggregateTimeout: 500, //防止重复保存频繁重新编译,500毫米内重复保存不打包
        poll: 1000 //每秒询问的文件变更的次数
    },
    plugins: [
        new WebpackBuildNotifierPlugin({
            title: "京程一灯配置环境",
            logo: resolve("./favicon.png"),
            suppressSuccess: true
        }),
        // new BundleAnalyzerPlugin(),
        //new CleanWebpackPlugin(['dist']),
        new HtmlWebpackPlugin({
            filename: '../views/index.html',
            template: './index.html',
            loading,
            minify: {
                // removeComments: true,
                collapseWhitespace: _modeflag,
                removeAttributeQuotes: _modeflag
            }
        }),
        new webpack.ContextReplacementPlugin(
            /angular(\\|\/)core/,
            resolve(__dirname, './'), // path to your src
            {}
        ),
        new MiniCssExtractPlugin({
            filename: _modeflag ? 'styles/[name].[contenthash:5].css' : 'styles/[name].css',
            chunkFilename: _modeflag ? 'styles/[name].[contenthash:5].css' : 'styles/[name].css', //[id]
        }),
        new FilterWarningsPlugin({
            exclude: /System.import/
        }),
        // new webpack.ProvidePlugin({ //引用框架 jquery 省去了import
        //     '$': 'jquery' //引用webpack
        // }),
        new ProgressBarPlugin(),
        // new InlineManifestWebpackPlugin(),
        //new InlineManifestWebpackPlugin('runtime'),
        // new CopyWebpackPlugin([ // from是要copy的文件，to是生成出来的文件
        //     { from: "node_modules/react/umd/react.xxx.js", to: "js/react.min.js" },
        //     { from: "node_modules/react-dom/umd/react-dom.xxx.js", to: "js/react-dom.min.js" },
        //     { from: "public/favicon.ico", to: "favicon.ico" }
        // ])
    ],
    optimization: {
        nodeEnv: 'production',
        noEmitOnErrors: false,
        splitChunks: {
            cacheGroups: {
                commons: {
                    chunks: "initial",
                    name: "common",
                    minChunks: 2,
                    maxInitialRequests: 5,
                    minSize: 0
                }
            }
        },
        runtimeChunk: {
            name: 'runtime'
        }
    },
    //共享依赖 不打包
    externals: {
        'jquery': '$'
    },
    resolve: {
        extensions: [".ts", ".tsx", ".js", ".css", ".json"],
        modules: [
            resolve(__dirname, 'node_modules'), // 使用绝对路径指定 node_modules，不做过多查询
        ],
        alias: { //模快别名列表
            //react:resolve(__dirname, './node_modules/react/dist/react.min.js')
        }
    }
};
module.exports = merge(webpackConfig, _mergeConfig);