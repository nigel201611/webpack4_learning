import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RevenueDataService } from './revenue.service';
import { RevenueComponent } from './revenue.component';
@NgModule({
  declarations: [
    RevenueComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    RevenueComponent
  ],
  providers: [
    RevenueDataService
  ]
})
export class RevenueModule { }