import { Component, OnInit, Input } from "@angular/core";
import { RevenueDataService } from "./revenue.service";
import { Observable } from "rxjs";
import { User } from "./model/revenue-model";

@Component({
  selector: "app-revenue",
  templateUrl: "./revenue.component.html",
  styleUrls: ["./revenue.component.css"]
})
export class RevenueComponent implements OnInit {
  public user: User = new User();
  public error: Error;

  constructor(public revenueDataService: RevenueDataService) {
    console.log("RevenueDataService注入成功");
  }

  ngOnInit() {
    console.log("--- 核心组件初始化 ---");
    this.doInitData();
  }

  public doInitData(): void {
    this.revenueDataService.chartData().subscribe(
      data => {
        console.log("✅获取数据成功",data);
      },
      error => {
        console.error("❌",error);
      }
    );
  }
}
