import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { map } from "rxjs/operators";
import { Http, Headers, Response } from "@angular/http";
import { User } from "./model/revenue-model";

@Injectable()
export class RevenueDataService {
  public userLoginURL = "/api/test";
  public subject: Subject<User> = new Subject<User>();

  constructor(public http: Http) {}

  public get currentUser(): Observable<User> {
    return this.subject.asObservable();
  }

  public chartData() {
    return this.http.get(this.userLoginURL)
    .pipe(map((response: Response) => response.json()));
  }
}
