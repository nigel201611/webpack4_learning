const TYPES = {
    SafeRequest: Symbol.for('SafeRequest'),
};

export default TYPES;