require("./ydfooter.css");
export default {
    init() {
        // new Vue({
        //     el:"test",
        //     methods: {
                
        //     }
        // });
        // class Test extends React.components{

        // }
        // ReactDOM.render("<Test></Test>",document.getElementById("test"))
    }
}
//aop java 一模一样
//Nestjs  InversifyJS
//awilix-koa