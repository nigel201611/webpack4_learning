import "reflect-metadata";
import * as bodyParser from 'koa-bodyparser';
 import "./ioc/loader";
 import { buildProviderModule} from "./ioc/ioc";
import { Container } from 'inversify';
import { interfaces, InversifyKoaServer, TYPE } from 'inversify-koa-utils';
 
let container = new Container();
//核心 告诉container 你用我的方式去找 @provide @injectable
container.load(buildProviderModule())
// create server
let server = new InversifyKoaServer(container);
server.setConfig((app) => {
  // add body parser
  app.use(bodyParser());
});
 
let app = server.build();
app.listen(3000);