import {fluentProvide,provide, buildProviderModule} from "inversify-binding-decorators";
import * as Router from "koa-router";
import {TYPE,controller,interfaces,httpGet} from "inversify-koa-utils";
import {inject} from "inversify";
let proddeController = function(identifer,name){
    return fluentProvide(identifer)
    .whenTargetNamed(name)
    .done();
}
export {proddeController,Router, provide, controller,interfaces,inject,httpGet,buildProviderModule};