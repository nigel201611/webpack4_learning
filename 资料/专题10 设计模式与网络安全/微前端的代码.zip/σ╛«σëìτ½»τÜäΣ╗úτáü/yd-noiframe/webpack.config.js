const VueLoaderPlugin = require('vue-loader/lib/plugin');
const WebpackSystemRegister = require('webpack-system-register');
module.exports = {
    entry: {
        index: "./src/index.vue"
    },
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                use: [
                  { loader: "vue-style-loader" },
                  { loader: "css-loader" }
                ]
            }
        ]
    },
    plugins: [
        new VueLoaderPlugin(),
        new WebpackSystemRegister({}),
    ]
}
//chunkid