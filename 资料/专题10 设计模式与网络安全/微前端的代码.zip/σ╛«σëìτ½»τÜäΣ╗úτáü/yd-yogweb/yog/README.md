YOG2 框架基础运行时模板

==============================

```
npm i -g yog2
yog2 init project
```
