// const result = window.performance.getEntriesByType("paint");
// console.log(result);
const observer = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        console.log(entry);
        console.log(entry.name + "执行时间", entry.startTime + entry.duration);
    }
});

observer.observe({
    entryTypes: ["paint"]
});