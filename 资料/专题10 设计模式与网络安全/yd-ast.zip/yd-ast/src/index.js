import a from './test';
console.log(a);
