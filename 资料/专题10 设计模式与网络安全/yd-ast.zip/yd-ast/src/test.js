import b from './message'
const a = 'hello' + b
export default a;
