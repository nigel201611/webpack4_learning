const b = ' world'
export default b
