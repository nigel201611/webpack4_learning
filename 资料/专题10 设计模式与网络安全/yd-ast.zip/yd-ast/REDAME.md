##如何运行?
 npm install
 ydwebpack
 或者可以直接 ./bin/ydpack