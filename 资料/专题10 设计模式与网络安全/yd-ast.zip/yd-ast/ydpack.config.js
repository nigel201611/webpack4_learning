module.exports = {
    entry: './src/index.js',
    output: './dist/index.js'
}